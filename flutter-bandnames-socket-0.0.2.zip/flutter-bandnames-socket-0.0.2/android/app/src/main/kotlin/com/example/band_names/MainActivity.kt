package com.example.band_names

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
