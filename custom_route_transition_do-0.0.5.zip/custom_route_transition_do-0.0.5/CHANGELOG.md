## [0.0.5] - Readme Actualizado
* Actualización del Readme

## [0.0.4] - Ejemplo añadido
* Corregido problema de la duración

## [0.0.3] - Ejemplo añadido
* main.dart añadido

## [0.0.2] - Mejoras en la documentación
* Ejemplo añadido
* Comentarios
* etc.

## [0.0.1] - Primera entrega
* Versión inicial
