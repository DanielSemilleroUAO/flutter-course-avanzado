# Route Transitions

Este paquete ayuda a la transición de rutas.

## Ejemplo de uso

```
RouteTransitions(
    context: context, 
    child: Page2(),
    animation: AnimationType.fadeIn,
);
```



