

class Usuario {
  bool online;
  String email;
  String nombre;
  String uid;

  Usuario({
    this.online,
    this.email,
    this.nombre,
    this.uid
  });

}