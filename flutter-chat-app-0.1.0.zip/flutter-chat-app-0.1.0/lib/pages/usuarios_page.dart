import 'package:flutter/material.dart';


class UsuariosPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('UsuariosPage'),
     ),
   );
  }
}