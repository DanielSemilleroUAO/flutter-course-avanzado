package com.fernandoherrera.flutterauthapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
